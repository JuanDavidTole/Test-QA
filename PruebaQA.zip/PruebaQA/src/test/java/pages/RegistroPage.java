/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class RegistroPage {

    private WebDriver driver;

    private By nombre =
            By.xpath("//input[@placeholder='Enter first name']");

    private By apellido =
            By.xpath("//input[@placeholder='Enter last name']");

    private By telefono =
            By.xpath("//input[@placeholder='Enter phone number']");

    private By pais =
            By.tagName("select");

    private By correo =
            By.xpath("//input[@placeholder='Enter email']");

    private By password =
            By.xpath("//input[@placeholder='Password']");

    private By terminos =
            By.xpath("//input[@type='checkbox']");

    private By botonRegistrar =
            By.xpath("//button[contains(text(),'Register')]");

    public RegistroPage(WebDriver driver) {
        this.driver = driver;
    }

    public void escribirNombre(String texto) {
        driver.findElement(nombre).sendKeys(texto);
    }

    public void escribirApellido(String texto) {
        driver.findElement(apellido).sendKeys(texto);
    }

    public void escribirTelefono(String texto) {
        driver.findElement(telefono).sendKeys(texto);
    }

    public void seleccionarPais(int indice) {

        Select select = new Select(
                driver.findElement(pais)
        );

        select.selectByIndex(indice);
    }

    public void escribirCorreo(String texto) {
        driver.findElement(correo).sendKeys(texto);
    }

    public void escribirPassword(String texto) {
        driver.findElement(password).sendKeys(texto);
    }

    public void aceptarTerminos() {

        if (!driver.findElement(terminos).isSelected()) {
            driver.findElement(terminos).click();
        }
    }

    public void registrar() {
        driver.findElement(botonRegistrar).click();
    }
}