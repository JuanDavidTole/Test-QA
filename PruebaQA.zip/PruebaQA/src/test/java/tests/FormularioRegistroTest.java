/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package tests;

import base.baseTest;
import pages.RegistroPage;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class FormularioRegistroTest extends baseTest {

    private RegistroPage registro;

    @BeforeEach
    public void setUp() {

        iniciarNavegador();

        registro = new RegistroPage(driver);
    }

    @Test
    public void registrarAspirante() {

        registro.escribirNombre("David");

        registro.escribirApellido("Prueba");

        registro.escribirTelefono("3001234567");

        registro.seleccionarPais(1);

        registro.escribirCorreo(
                "david.prueba@test.com"
        );

        registro.escribirPassword(
                "Password123"
        );

        registro.aceptarTerminos();

        registro.registrar();
    }

    @AfterEach
    public void tearDown() {

        cerrarNavegador();
    }
}