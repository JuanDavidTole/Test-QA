/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.ucompensar.pruebaqa;

/**
 *
 * @author toled
 */
public class PruebaQA {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
